#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h> 

int main()
{
    pid_t pidC;
    printf("** proc PID= %d comienza ihjo_0** \n",getpid());

    pidC = fork();

    if(pidC > 0){           //Se esta ejecutando el padre
        printf("** proc PID= %d comienza hijo_1** \n",getpid());
        int status;
        wait(&status);
    }
    else if(pidC == 0){     //Se esta ejecutando el hijo
        printf("** proc PID= %d comienza hijo_2** \n",getpid());
        
        /** lee el codigo del hijo.c */
        execlp ("./bin/nieto","", NULL);
		printf("Si ves esto, no se pudo ejecutar el programa nieto\n");
    }
    else{
        //si es -1 es error, el hijo no ha podido ser creado
    }
}

/*#include <unistd.h>
#include <stdio.h>

int main()
{
    printf("hola\n");
}*/
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <signal.h> 
#include <string.h>
#include <setjmp.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
//#include <sys/siginfo.h> 
/*static void hdl (int sig, siginfo_t *siginfo, void *context) { 
printf ("Sending PID: %ld, UID: %ld\n",(long)siginfo->si_pid, (long)siginfo->si_uid); 
}
int main (int argc, char *argv[]) {
        printf("entraaa crj T_T");

    struct sigaction act;
    memset (&act, 0, sizeof(act));
    act.sa_sigaction = &hdl;
    act.sa_flags = SA_SIGINFO;
    if (sigaction(SIGTERM, &act, NULL) < 0) {
        perror ("sigaction");
        return 1;
        
    }
    while (1)
        sleep (10);
    return 0;
}*/
/*
static int exit_flag = 0; 
static void hdl (int sig){ 
    exit_flag = 1;     
} 
int main (int argc, char *argv[]){ 
    struct sigaction act;  
    memset (&act, '\0', sizeof(act)); 
    act.sa_handler = &hdl;   
    if (sigaction(SIGTERM, &act, NULL) < 0) {  
        perror ("sigaction");      
        return 1;       }   
        while (!exit_flag)  
            ;   
return 0; }

*/

jmp_buf env; // for saving longjmp environment
int count = 0;

void handler(int sig, siginfo_t *siginfo, void *context)
{ siginfo->si_pid=getpid();
    printf("handler: from PID=%d ; SIGNO=%d ; CODE=%d Errno=%d count=%d\n",
           siginfo->si_pid, siginfo->si_signo, siginfo->si_code ,siginfo->si_errno,            ++count);
    if (count >= 4) // let it occur up to 4 times
        longjmp(env, 1234);
}

void BAD()
{
    int *ip = 0;
    printf("in BAD(): try to dereference NULL pointer\n");
    *ip = 123; // dereference a NULL pointer
    printf("should not see this line\n");
}

int main(int argc, char *argv[])
{  // printf("here pir=%d y su padre = %d",getpid(),getppid());
    int r;
    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_sigaction = &handler;
    act.sa_flags = SA_SIGINFO;
    sigaction(SIGSEGV, &act, NULL); // install SIGSEGV catcher 

    //sigaction(SIGHUP, &act, NULL); // install SIGSEGV catcher 

    //sigaction(SIGINT, &act, NULL); // install SIGSEGV catcher 

    //sigaction(SIGTSTP, &act, NULL); // install SIGSEGV catcher 
    /*act.sa_flags =0;
    
    sigset_t mask;
    sigemptyset(&mask);
    sigaddset(&mask, SIGTERM);
    sigaction(SIGTERM, &act, NULL); // install SIGSEGV catcher 
    act.sa_mask = mask;
    pause();*/
    if ((r = setjmp(env)) == 0) // call setjmp(env)
        BAD(); 
    
    // call BAD()
    else 
        printf("proc %d survived SEGMENTATION FAULT: r=%d\n", getpid(), r);
    
    printf("proc %d looping\n", getpid());
    //while (1)
      //  ;
    
    /*struct sigaction act2;
    memset(&act2, 0, sizeof(act2));
    act2.sa_sigaction = &handler;
    act2.sa_flags = SA_SIGINFO;
    sigaction(SIGSEGV, &act2, NULL); // install SIGSEGV catcher */

    //sigaction(SIGHUP, &act, NULL); // install SIGSEGV catcher 

    //sigaction(SIGINT, &act, NULL); // install SIGSEGV catcher 

    //sigaction(SIGTSTP, &act, NULL); // install SIGSEGV catcher 
    /*act.sa_flags =0;
    
    sigset_t mask;
    sigemptyset(&mask);
    sigaddset(&mask, SIGTERM);
    sigaction(SIGTERM, &act, NULL); // install SIGSEGV catcher 
    act.sa_mask = mask;
    pause();*/
    /*--------------------------------------------------------*/
    /*if ((r = setjmp(env)) == 0) // call setjmp(env)
        BAD(); 
    
    // call BAD()
    else 
        printf("proc %d survived SEGMENTATION FAULT: r=%d\n", getpid(), r);
    
    printf("proc %d looping\n", getpid());*/
    
    return 0;
}
